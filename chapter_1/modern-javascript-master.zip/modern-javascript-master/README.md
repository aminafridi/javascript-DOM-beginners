## Modern JavaScript - Novice to Ninja
All lecture files from the Modern JavaScript (Novice to Ninja) course on Udemy.

### How to use this repository

Each lesson in the course has it's own branch in the repository. To see the code for a specific lesson, just select that branch from the branch drop-down (top-left). E.g. The lesson-20 branch contains the final code for lesson 20 in the course.

**Course link:** [Modern JavaScript - Novice to Ninja](https://www.udemy.com/modern-javascript-from-novice-to-ninja/)


